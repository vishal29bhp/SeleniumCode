package seleniumcode;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;

import constants.AppConstants;
import elementlocators.ElementLocators;

public class ListenerMainClass {
	
	public static void main (String [] args) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", AppConstants.chromeDriverLocation);
		WebDriver driver = new ChromeDriver();
		EventFiringWebDriver eventHandler = new EventFiringWebDriver(driver); 
		ListenerTest listener = new ListenerTest(); 
		//Registering with EventFiringWebDriver
                //Register method allows to register our implementation of WebDriverEventListner to listen to the WebDriver events
		eventHandler.register(listener); 
		//navigating to the webpage "www.softwaretestingmaterial.com"
		eventHandler.manage().window().maximize();
		eventHandler.navigate().to(AppConstants.loginUrl); 
		eventHandler.manage().window().maximize();
		eventHandler.findElement(By.id(ElementLocators.emailTextFieldLocator)).sendKeys(AppConstants.email);
		eventHandler.findElement(By.id(ElementLocators.pwdTextFieldLocator)).sendKeys(AppConstants.pwd);
		eventHandler.findElement(By.id(ElementLocators.loginButtonLocator)).click();
		//navigating to the webpage "www.softwaretestingmaterial.com/category/selenium/"
		Thread.sleep(3000);
		eventHandler.navigate().to(AppConstants.navigateUrl); 
		//navigating back to the first page
		eventHandler.navigate().back();
		eventHandler.quit();
                //Unregister allows to detach
		eventHandler.unregister(listener);
		System.out.println("End of Listners Class");
	}
}